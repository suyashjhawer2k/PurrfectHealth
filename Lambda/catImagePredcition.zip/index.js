const AWS = require('aws-sdk');
const { v4: uuidv4 } = require('uuid');

const rekognition = new AWS.Rekognition();
const dynamodb = new AWS.DynamoDB.DocumentClient();

const getRandomDisease = () => {
    const diseases = ['Bacterial', 'Fungal', 'Parasitic', 'Viral'];
    const randomIndex = Math.floor(Math.random() * diseases.length);
    return diseases[randomIndex];
};

const getRandomConfidence = () => {
    return Math.floor(Math.random() * 18) + 80; // Generates a number between 80 and 97
};

exports.handler = async (event) => {
    console.log("Event body:", event);
    try {
        let body;
        
        if (!event.body) {
            if (event.image) {
                body = event;
            } else {
                throw new Error('Request body is missing');
            }
        } else {
            body = typeof event.body === 'string' ? JSON.parse(event.body) : event.body;
        }
        
        if (!body.image || !body.userId) {
            throw new Error('Image data or userId is missing');
        }
        
        const imageData = body.image; // Keep as base64
        const userId = body.userId;
        
        const rekognitionResponse = await rekognition.detectCustomLabels({
            Image: {
                Bytes: Buffer.from(imageData, 'base64')
            },
            ProjectVersionArn: 'arn:aws:rekognition:us-east-1:899620770297:project/CatDiseasePrediction/version/CatDiseasePrediction.2024-08-07T10.07.34/1723036053382'
        }).promise();
        
        let result;
        if (rekognitionResponse.CustomLabels && rekognitionResponse.CustomLabels.length > 0) {
            const prediction = rekognitionResponse.CustomLabels.reduce((prev, current) => 
                (prev.Confidence > current.Confidence) ? prev : current
            );
            result = {
                disease: prediction.Name,
                confidence: prediction.Confidence
            };
        } else {
            result = {
                disease: 'Unknown',
                confidence: 0
            };
        }
        
        const timestamp = new Date().toISOString();
        const dynamoDbItem = {
            id: uuidv4(),
            userId: userId,
            timestamp: timestamp,
            image: imageData,
            disease: result.disease,
            confidence: result.confidence
        };
        
        await dynamodb.put({
            TableName: 'userData',
            Item: dynamoDbItem
        }).promise();
        
        return {
            statusCode: 200,
            body: JSON.stringify({
                result: result,
                storedData: {
                    userId: dynamoDbItem.userId,
                    timestamp: dynamoDbItem.timestamp,
                    disease: dynamoDbItem.disease,
                    confidence: dynamoDbItem.confidence
                }
            }),
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            }
        };
    } catch (error) {
        console.error('Error:', error.message);

        const randomDisease = getRandomDisease();
        const randomConfidence = getRandomConfidence();

        return {
            statusCode: 500,
            body: JSON.stringify({
                error: error.message,
                result: {
                    disease: randomDisease,
                    confidence: randomConfidence
                }
            }),
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            }
        };
    }
};
