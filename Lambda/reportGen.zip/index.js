const AWS = require('aws-sdk');
const sns = new AWS.SNS();

const topicArn = 'arn:aws:sns:us-east-1:899620770297:CatDiseaseReports';

exports.handler = async (event) => {


    console.log("Event body:", event);

    let body;

    body = typeof event === 'string' ? JSON.parse(event) : event;

    try {

        // Ensure email and disease are present
        if (!body.email || !body.disease) {
            throw new Error('Email or disease is missing');
        }

        const email = body.email;
        const disease = body.disease.toLowerCase();

        // Check if the email is subscribed to the SNS topic
        const subscriptions = await sns.listSubscriptionsByTopic({ TopicArn: topicArn }).promise();
        const isSubscribed = subscriptions.Subscriptions.some(sub => sub.Endpoint === email);

        if (!isSubscribed) {
            return {
                statusCode: 400,
                body: JSON.stringify({ message: 'Email is not subscribed to the topic' }),
                headers: {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                }
            };
        }

        // Determine the disease type
        let diseaseType;
        if (disease.includes('bacterial')) {
            diseaseType = 'Bacterial';
        } else if (disease.includes('fungal')) {
            diseaseType = 'Fungal';
        } else if (disease.includes('parasitic')) {
            diseaseType = 'Parasitic';
        } else if (disease.includes('viral')) {
            diseaseType = 'Viral';
        } else {
            diseaseType = 'Unknown';
        }

        // Prepare the email content
        const subject = `Cat Disease Alert: ${diseaseType}`;
        let message = `Your cat has been diagnosed with a ${diseaseType.toLowerCase()} disease: ${disease}.\n\n`;

        switch (diseaseType) {
            case 'Bacterial':
                message += 'Bacterial diseases in cats are often treated with antibiotics. Please consult your veterinarian for proper treatment.';
                break;
            case 'Fungal':
                message += 'Fungal diseases in cats may require antifungal medications. A veterinary examination is recommended for accurate diagnosis and treatment.';
                break;
            case 'Parasitic':
                message += 'Parasitic diseases in cats can be treated with appropriate antiparasitic medications. Regular deworming and flea prevention are important.';
                break;
            case 'Viral':
                message += 'Viral diseases in cats often require supportive care. Some may be prevented through vaccination. Consult your vet for the best course of action.';
                break;
            default:
                message += 'The disease type is unknown. Please consult your veterinarian for proper diagnosis and treatment.';
        }

        // Send the email using SNS
        await sns.publish({
            TopicArn: topicArn,
            Subject: subject,
            Message: message,
            MessageAttributes: {
                'email': {
                    DataType: 'String',
                    StringValue: email
                }
            }
        }).promise();

        return {
            statusCode: 200,
            body: JSON.stringify({ message: 'Email sent successfully' }),
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            }
        };
    } catch (error) {
        console.error('Error:', error.message);
        return {
            statusCode: 500,
            body: JSON.stringify({ error: error.message }),
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            }
        };
    }
};