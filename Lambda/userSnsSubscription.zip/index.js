const AWS = require('aws-sdk');
const sns = new AWS.SNS();

exports.handler = async (event) => {
    console.log("Event body:", event);
    
    try {
        // Extract email from the Cognito event
        let body;
        body = typeof event === 'string' ? JSON.parse(event) : event;

        if (!body.email) {
            throw new Error('Email is missing from user attributes');
        }

        const topicArn = 'arn:aws:sns:us-east-1:899620770297:CatDiseaseReports';

        // Subscribe the email to the SNS topic
        const params = {
            Protocol: 'EMAIL',
            TopicArn: topicArn,
            Endpoint: body.email
        };

        const result = await sns.subscribe(params).promise();

        console.log('Subscription result:', result);

        return event;
    } catch (error) {
        console.error('Error:', error.message);
        throw error; // Rethrow the error to signal failure to Cognito
    }
};