const AWS = require('aws-sdk');
const dynamodb = new AWS.DynamoDB.DocumentClient();

exports.handler = async (event) => {
    console.log("Event body:", event);
    try {
        let body;

        // Ensure the body is present
        if (!event.body) {
            if (event.userId) {
                body = event
            }
            else {
                throw new Error('Request body is missing');
            }
        } else {
            body = typeof event.body === 'string' ? JSON.parse(event.body) : event.body;
        }

        // Ensure the userId is present
        if (!body.userId) {
            throw new Error('userId is missing');
        }

        const userId = body.userId;

        // Scan DynamoDB for all items with the given userId
        const params = {
            TableName: 'userData',
            FilterExpression: 'userId = :userId',
            ExpressionAttributeValues: {
                ':userId': userId
            }
        };

        const result = await dynamodb.scan(params).promise();

        return {
            statusCode: 200,
            body: JSON.stringify(result.Items),
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            }
        };
    } catch (error) {
        console.error('Error:', error.message);
        return {
            statusCode: 500,
            body: JSON.stringify({ error: error.message }),
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            }
        };
    }
};